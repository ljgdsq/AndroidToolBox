package com.example.androidtoolbox.widget;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.androidtoolbox.R;

public class ImageViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_view);
//
//        前景(对应src属性):setImageDrawable( );
//        背景(对应background属性):setBackgroundDrawable( );


    }
}
