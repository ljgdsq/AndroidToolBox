package com.example.androidtoolbox.layout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.androidtoolbox.R;

public class RelativeLayoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_releative_layout);
    }
}
