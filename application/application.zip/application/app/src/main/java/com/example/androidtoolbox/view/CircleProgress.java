package com.example.androidtoolbox.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.Nullable;
public class CircleProgress extends View {
    public CircleProgress(Context context) {
        super(context);
    }

    public CircleProgress(Context context, @androidx.annotation.Nullable AttributeSet attrs) {
        super(context, attrs);
    }


}
